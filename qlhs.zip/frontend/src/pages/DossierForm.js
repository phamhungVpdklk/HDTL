import { Form, Input, InputNumber, Button, Select, Card } from 'antd';
import { useState } from 'react';
import CostTable from '../components/CostTable';
import api from '../api';

export default function DossierForm() {
  const [result, setResult] = useState(null);

  const onFinish = async (values) => {
    const res = await api.post('/dossiers', values);
    setResult(res.data);
  };

  return (
    <Card title="Tạo Hồ sơ" style={{ maxWidth: 800, margin: 'auto' }}>
      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item label="Họ tên" name={['customer','full_name']} rules={[{ required: true }]}>
          <Input />
        </Form.Item>
        <Form.Item label="Địa chỉ" name={['customer','address']}>
          <Input />
        </Form.Item>
        <Form.Item label="SĐT" name={['customer','phone_number']}>
          <Input />
        </Form.Item>

        <Form.List name="services">
          {(fields, { add, remove }) => (
            <>
              {fields.map(({ key, name }) => (
                <Card key={key} type="inner" className="mb-2">
                  <Form.Item label="Loại DV" name={[name,'type']} rules={[{ required: true }]}>
                    <Select>
                      <Select.Option value="land_survey">Đo chỉnh lý</Select.Option>
                      <Select.Option value="blueprint">Biên vẽ HSKT</Select.Option>
                      <Select.Option value="photocopy">Phô tô</Select.Option>
                      <Select.Option value="extract">Khai thác thông tin</Select.Option>
                    </Select>
                  </Form.Item>
                  <Form.Item label="Mô tả" name={[name,'description']}>
                    <Input />
                  </Form.Item>
                  <Form.Item label="Số lượng" name={[name,'quantity']} initialValue={1}>
                    <InputNumber min={1} />
                  </Form.Item>
                  <Button danger type="link" onClick={() => remove(name)}>Xoá</Button>
                </Card>
              ))}
              <Form.Item>
                <Button type="dashed" onClick={() => add()}>+ Thêm dịch vụ</Button>
              </Form.Item>
            </>
          )}
        </Form.List>

        <Button type="primary" htmlType="submit">Lưu</Button>
      </Form>

      {result && <CostTable data={result} />}
    </Card>
  );
}
