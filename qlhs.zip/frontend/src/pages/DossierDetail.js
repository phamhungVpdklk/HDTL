import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import api from '../api';
import { Descriptions, Button, message } from 'antd';

export default function DossierDetail() {
  const { id } = useParams();
  const [dossier,setDossier]=useState(null);

  useEffect(()=>{
    api.get('/dossiers').then(r=>{
      setDossier(r.data.find(d=>d.id===Number(id)));
    })
  },[id]);

  const exportDoc = async (template) => {
    const res = await api.post(`/dossiers/${id}/export`, { template }, { responseType: 'blob' });
    const blob = new Blob([res.data], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${template.replace('.docx','')}-${id}.docx`;
    link.click();
    message.success('Đã tải!');
  };

  if (!dossier) return null;

  return (
    <>
      <Descriptions title="Chi tiết hồ sơ" bordered column={1}>
        <Descriptions.Item label="Khách hàng">{dossier.full_name}</Descriptions.Item>
        <Descriptions.Item label="Tổng tiền">{parseInt(dossier.total_amount).toLocaleString()}</Descriptions.Item>
        <Descriptions.Item label="Trạng thái">{dossier.status}</Descriptions.Item>
      </Descriptions>
      <Button className="mt-3" onClick={()=>exportDoc('hop-dong.docx')}>Xuất Hợp đồng</Button>
      <Button className="mt-3 ml-2" onClick={()=>exportDoc('bien-ban-tl.docx')}>Xuất Biên bản TL</Button>
    </>
  );
}
