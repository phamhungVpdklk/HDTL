import { Table, Input, Button } from 'antd';
import { useEffect, useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';

export default function DossierDashboard() {
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/dossiers').then(r => setRows(r.data));
  }, []);

  const filtered = rows.filter(r => r.full_name.toLowerCase().includes(search.toLowerCase()));

  const columns = [
    { title: 'Mã', dataIndex: 'id' },
    { title: 'Khách hàng', dataIndex: 'full_name' },
    { title: 'Ngày tạo', dataIndex: 'created_at' },
    { title: 'Trạng thái', dataIndex: 'status' },
    { title: ' ', render: (_,rec) => <Button type="link" onClick={() => navigate('/dossier/'+rec.id)}>Xem</Button>}
  ];
  return (
    <>
      <Input.Search placeholder="Tìm kiếm" style={{maxWidth:300, marginBottom:16}} onChange={e=>setSearch(e.target.value)} />
      <Table rowKey="id" dataSource={filtered} columns={columns} />
    </>
  );
}
