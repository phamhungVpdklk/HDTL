import { Table, Typography } from 'antd';
const { Title } = Typography;

export default function CostTable({ data }) {
  const cols = [
    { title:'Mô tả', dataIndex:'description' },
    { title:'SL', dataIndex:'quantity', align:'right' },
    { title:'Đơn giá', dataIndex:'unit_price', align:'right', render:v=>v.toLocaleString() },
    { title:'Thành tiền', dataIndex:'final_price', align:'right', render:v=>v.toLocaleString() },
  ];
  return (
    <>
      <Title level={4}>Chi tiết chi phí</Title>
      <Table pagination={false} columns={cols}
        dataSource={data.services.map((s,i)=>({...s,key:i}))}
        summary={()=><>
          <Table.Summary.Row>
            <Table.Summary.Cell colSpan={3} align="right">Cộng</Table.Summary.Cell>
            <Table.Summary.Cell align="right">{(data.dossier.total_amount - data.vat).toLocaleString()}</Table.Summary.Cell>
          </Table.Summary.Row>
          <Table.Summary.Row>
            <Table.Summary.Cell colSpan={3} align="right">Thuế 8%</Table.Summary.Cell>
            <Table.Summary.Cell align="right">{data.vat.toLocaleString()}</Table.Summary.Cell>
          </Table.Summary.Row>
          <Table.Summary.Row>
            <Table.Summary.Cell colSpan={3} align="right"><strong>TỔNG</strong></Table.Summary.Cell>
            <Table.Summary.Cell align="right"><strong>{data.dossier.total_amount.toLocaleString()}</strong></Table.Summary.Cell>
          </Table.Summary.Row>
        </>}
      />
    </>
  );
}
