import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import DossierForm from './pages/DossierForm';
import DossierDashboard from './pages/DossierDashboard';
import DossierDetail from './pages/DossierDetail';

const { Header, Content } = Layout;

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Header>
          <Menu theme="dark" mode="horizontal" items={[
            { key: 'new', label: 'Tạo hồ sơ', onClick: () => window.location.href = '/' },
            { key: 'list', label: 'Danh sách', onClick: () => window.location.href = '/dashboard' },
          ]}/>
        </Header>
        <Content style={{ padding: 24 }}>
          <Routes>
            <Route path="/" element={<DossierForm />} />
            <Route path="/dashboard" element={<DossierDashboard />} />
            <Route path="/dossier/:id" element={<DossierDetail />} />
          </Routes>
        </Content>
      </Layout>
    </BrowserRouter>
  );
}
