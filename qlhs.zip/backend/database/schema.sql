-- customers
CREATE TABLE IF NOT EXISTS customers (
    id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    address TEXT,
    phone_number VARCHAR(20)
);

-- dossiers
CREATE TABLE IF NOT EXISTS dossiers (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    status VARCHAR(50) DEFAULT 'Mới tạo',
    total_amount BIGINT,
    amount_paid BIGINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_dossiers_customer ON dossiers(customer_id);

-- dossier_services
CREATE TABLE IF NOT EXISTS dossier_services (
    id SERIAL PRIMARY KEY,
    dossier_id INTEGER NOT NULL REFERENCES dossiers(id) ON DELETE CASCADE,
    description TEXT,
    quantity INTEGER CHECK (quantity > 0),
    unit_price BIGINT,
    final_price BIGINT
);

CREATE INDEX IF NOT EXISTS idx_services_dossier ON dossier_services(dossier_id);
