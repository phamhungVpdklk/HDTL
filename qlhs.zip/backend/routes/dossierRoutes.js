import { Router } from 'express';
import { createDossier, listDossiers, exportDoc } from '../controllers/dossierController.js';

const router = Router();

router.post('/dossiers', createDossier);
router.get('/dossiers', listDossiers);
router.post('/dossiers/:id/export', exportDoc);

export default router;
