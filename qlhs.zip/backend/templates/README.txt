Place your Word templates (hop-dong.docx, bien-ban-tl.docx) here.
