export function calculateLandSurveyPrice(area) {
  if (area <= 300) return 1_085_000;
  if (area <= 1000) return 1_085_000 + (area - 300) * 1200;
  return 1_085_000 + 700 * 1200 + (area - 1000) * 900;
}

export function calculateBlueprintDrawingPrice(plots) {
  let price = 0;
  for (let i = 1; i <= plots; i++) {
    if (i === 1) price += 500_000;
    else if (i <= 10) price += 500_000 * 0.8;
    else price += 500_000 * 0.6;
  }
  return price;
}

export function calcPhotocopyPrice(pages) {
  return pages * 1000;
}

export function calcInfoExtractionPrice(sheets) {
  return sheets * 10000;
}

export function calcVAT(amount) {
  return Math.round(amount * 0.08);
}
