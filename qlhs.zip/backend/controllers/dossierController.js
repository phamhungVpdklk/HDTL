import { pool } from '../db.js';
import {
  calculateLandSurveyPrice,
  calculateBlueprintDrawingPrice,
  calcPhotocopyPrice,
  calcInfoExtractionPrice,
  calcVAT,
} from '../pricingLogic.js';
import fs from 'fs';
import PizZip from 'pizzip';
import Docxtemplater from 'docxtemplater';

export async function createDossier(req, res) {
  const { customer, services } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows: cust } = await client.query(
      'INSERT INTO customers(full_name,address,phone_number) VALUES($1,$2,$3) RETURNING id',
      [customer.full_name, customer.address, customer.phone_number]
    );
    const customerId = cust[0].id;

    let total = 0;
    const svcValues = [];

    for (const sv of services) {
      let unit = 0;
      switch (sv.type) {
        case 'land_survey':
          unit = calculateLandSurveyPrice(sv.area);
          break;
        case 'blueprint':
          unit = calculateBlueprintDrawingPrice(sv.plots);
          break;
        case 'photocopy':
          unit = calcPhotocopyPrice(sv.pages);
          break;
        case 'extract':
          unit = calcInfoExtractionPrice(sv.sheets);
          break;
        default:
          unit = sv.unit_price ?? 0;
      }
      const final_price = unit * sv.quantity;
      total += final_price;
      svcValues.push({ ...sv, unit_price: unit, final_price });
    }

    const vat = calcVAT(total);
    total += vat;

    const { rows: dossierRows } = await client.query(
      'INSERT INTO dossiers(customer_id,status,total_amount,amount_paid) VALUES($1,$2,$3,$4) RETURNING *',
      [customerId, 'Mới tạo', total, 0]
    );
    const dossier = dossierRows[0];

    for (const sv of svcValues) {
      await client.query(
        `INSERT INTO dossier_services(dossier_id,description,quantity,unit_price,final_price)
         VALUES($1,$2,$3,$4,$5)`,
        [dossier.id, sv.description, sv.quantity, sv.unit_price, sv.final_price]
      );
    }

    await client.query('COMMIT');
    res.json({ dossier, services: svcValues, vat });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
}

export async function listDossiers(_, res) {
  const { rows } = await pool.query(
    `SELECT d.*, c.full_name
       FROM dossiers d
       JOIN customers c ON c.id = d.customer_id
     ORDER BY d.created_at DESC`
  );
  res.json(rows);
}

export async function exportDoc(req, res) {
  const { id } = req.params;
  const { template } = req.body;

  const { rows: dossiers } = await pool.query(
    `SELECT d.*, c.*
       FROM dossiers d
       JOIN customers c ON c.id = d.customer_id
      WHERE d.id = $1`,
    [id]
  );
  if (!dossiers.length) return res.status(404).send('Không tìm thấy hồ sơ');

  const { rows: services } = await pool.query(
    'SELECT * FROM dossier_services WHERE dossier_id=$1',
    [id]
  );

  const path = `templates/${template}`;
  if (!fs.existsSync(path)) return res.status(404).send('Không tìm thấy template');

  const zip = new PizZip(fs.readFileSync(path, 'binary'));
  const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

  doc.setData({
    dossier: dossiers[0],
    services,
    created_at: new Date().toLocaleDateString('vi-VN'),
  });

  try {
    doc.render();
  } catch (e) {
    console.error(e);
    return res.status(500).send('Lỗi render Word');
  }

  const buf = doc.getZip().generate({ type: 'nodebuffer' });
  const filename = `ho-so-${id}-${Date.now()}.docx`;
  res
    .status(200)
    .set({
      'Content-Type':
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': `attachment; filename="${filename}"`,
    })
    .send(buf);
}
